import { APP_VERSION } from "./constants.js";
import { categoryIcon, icons, loanIcon, merchantVisual } from "./icons.js";
import {
  accountBalance, euro, filterTransactions, loanProgress,
  monthKey, monthSummary, sortNewest, today, totalBalance
} from "./logic.js";
import { esc, field } from "./ui.js";
import { groupedCard, sectionHeader } from "./components/components.js";

export function createViews(context) {
  const { getData, navigate, openTransaction, openLoan, saveDashboard, getPWAState } = context;
  const data = () => getData();
  const category = id => data().categories.find(item => item.id === id);
  const account = id => data().accounts.find(item => item.id === id);

  function transactionRow(transaction, editable = false) {
    const visual = merchantVisual(transaction.description, transaction.type);
    const amountClass = transaction.status === "pending"
      ? "pending"
      : transaction.type === "income" ? "positive" : "negative";

    return `
      <div class="transaction-row" data-transaction="${transaction.id}">
        <div class="transaction-left">
          <div class="merchant-icon ${visual.className}">${visual.html ? visual.mark : esc(visual.mark)}</div>
          <div class="transaction-copy">
            <strong>${esc(transaction.description)}</strong>
            <div class="meta">${esc(category(transaction.categoryId)?.name ?? "—")} · ${esc(account(transaction.accountId)?.name ?? "—")}</div>
          </div>
        </div>
        <div class="transaction-end">
          <div class="transaction-amount ${amountClass}">
            ${transaction.type === "income" ? "+" : "-"}${euro(transaction.amount)}
          </div>
          ${editable ? `<button class="row-edit" data-edit="${transaction.id}" aria-label="Buchung bearbeiten">${icons.edit}</button>` : `<span class="row-chevron">${icons.chevron}</span>`}
        </div>
      </div>
    `;
  }

  function dashboard() {
    const current = data();
    const dashboardConfig = current.settings.dashboard;
    const summary = monthSummary(current);
    const balance = totalBalance(current);
    const pending = current.transactions.filter(item => item.status === "pending");

    const modules = {
      balance: () => `
        <section class="dashboard-module hero-module">
          <button class="card hero hero-button" data-nav="accounts">
            <div class="hero-row">
              <div class="hero-icon">${icons.wallet}</div>
              <div class="hero-copy">
                <div class="hero-label">Gesamtkontostand</div>
                <div class="hero-value ${balance > 0 ? "positive" : balance < 0 ? "negative" : ""}" data-animate-number="${balance}">${euro(balance)}</div>
                <div class="hero-sub"><span>Verfügbar diesen Monat</span><strong>${euro(summary.available)}</strong></div>
              </div>
            </div>
          </button>
        </section>
      `,
      summary: () => `
        <section class="dashboard-module summary-module">
          <div class="card summary-card">
            <button class="summary-item summary-action" data-nav="income">
              <div class="metric-head"><div class="metric-icon income">${icons.income}</div><div class="metric-label">Einnahmen</div></div>
              <div class="metric-value" data-animate-number="${summary.income}">${euro(summary.income)}</div>
            </button>
            <div class="summary-divider" aria-hidden="true"></div>
            <button class="summary-item summary-action" data-nav="expenses">
              <div class="metric-head"><div class="metric-icon expense">${icons.expense}</div><div class="metric-label">Ausgaben</div></div>
              <div class="metric-value" data-animate-number="${summary.expense}">${euro(summary.expense)}</div>
            </button>
          </div>
        </section>
      `,
      pending: () => {
        const oldestPending = sortNewest(pending).at(-1);
        const oldestLabel = oldestPending
          ? new Date(`${oldestPending.date}T00:00:00`).toLocaleDateString("de-DE", {
              day: "2-digit",
              month: "2-digit",
              year: "numeric"
            })
          : null;

        return `
          <section class="dashboard-module pending-module">
            <button class="card pending-bar" data-nav="pending">
              <span class="pending-icon">${icons.pending}</span>
              <span class="pending-label">Zu prüfen</span>
              <span class="pending-count">${pending.length}</span>
              <span class="pending-date">${oldestLabel ? `seit ${oldestLabel}` : "nichts offen"}</span>
              <span class="row-chevron">${icons.chevron}</span>
            </button>
          </section>
        `;
      },
      loans: () => loanPreview(dashboardConfig.loans.count),
      transactions: () => transactionPreview(dashboardConfig.transactions.count)
    };

    const fixed = modules.balance() + modules.summary();
    const configurable = ["pending", "loans", "transactions"]
      .filter(key => dashboardConfig[key]?.enabled !== false)
      .sort((a, b) => Number(dashboardConfig[a]?.order || 99) - Number(dashboardConfig[b]?.order || 99))
      .map(key => modules[key]?.() ?? "")
      .join("");

    const customize = `
      <section class="dashboard-module dashboard-customize">
        <button class="card customize-card" data-nav="dashboard-settings">
          <span class="customize-icon">${icons.arrange}</span>
          <span>Anpassen</span>
        </button>
      </section>
    `;

    return fixed + configurable + customize;
  }

  function loanPreview(count = 3) {
    const allLoans = [...data().loans]
      .sort((a, b) => Number(b.remaining) - Number(a.remaining));
    const requested = Math.max(0, Number(count) || 0);
    const visibleCount = Math.min(3, requested || 3);
    const loans = allLoans.slice(0, visibleCount);
    const hiddenCount = Math.max(0, allLoans.length - loans.length);

    if (!loans.length) return "";

    const rows = loans.map(loan => {
      const { percent } = loanProgress(loan);
      return `
        <button class="grouped-row loan-row" data-loan="${loan.id}">
          <span class="grouped-icon loan-symbol">${loanIcon(loan.type)}</span>
          <span class="grouped-main">
            <span class="grouped-title">${esc(loan.name)}</span>
            <span class="slim-progress" aria-hidden="true">
              <span class="slim-progress-fill" style="--row-progress:${percent}%"></span>
            </span>
          </span>
          <span class="grouped-values">
            <strong>${euro(loan.remaining)}</strong>
          </span>
          <span class="row-chevron">${icons.chevron}</span>
        </button>
      `;
    }).join("");

    const more = hiddenCount
      ? `<button class="grouped-more" data-nav="loans">+${hiddenCount} weitere Kredite <span class="row-chevron">${icons.chevron}</span></button>`
      : "";

    return `
      <section class="dashboard-module">
        ${sectionHeader({ title: "Kredite", action: `Alle anzeigen ${icons.chevron}`, actionTarget: "loans" })}
        ${groupedCard(rows + more, "loan-group")}
      </section>
    `;
  }

  function transactionPreview(count = 6) {
    const transactions = sortNewest(data().transactions).slice(0, Math.max(0, Number(count)));
    if (!transactions.length) return "";

    return `
      <section class="dashboard-module">
        ${sectionHeader({ title: "Letzte Buchungen", action: `Alle anzeigen ${icons.chevron}`, actionTarget: "transactions" })}
        <div class="card transaction-list">${transactions.map(item => transactionRow(item)).join("")}</div>
      </section>
    `;
  }

  function transactions(filters) {
    const items = filterTransactions(data(), filters);
    return `
      <div class="section-title transactions-heading">
        <h2 class="page-heading">Buchungen</h2>
        <button class="btn primary compact-new" data-open-add>${icons.plus}<span>Neu</span></button>
      </div>
      <div class="card page-card filters">
        <div class="filters-title"><span>${icons.search}</span><strong>Filtern</strong></div>
        <div class="form">
          ${field("Suche", `<input id="filterQuery" value="${esc(filters.query)}" placeholder="Händler, Kategorie oder Betrag">`)}
          <div class="grid two">
            ${field("Konto", `<select id="filterAccount"><option value="">Alle</option>${data().accounts.map(item => `<option value="${item.id}" ${filters.account === item.id ? "selected" : ""}>${esc(item.name)}</option>`).join("")}</select>`)}
            ${field("Kategorie", `<select id="filterCategory"><option value="">Alle</option>${data().categories.map(item => `<option value="${item.id}" ${filters.category === item.id ? "selected" : ""}>${esc(item.name)}</option>`).join("")}</select>`)}
            ${field("Person", `<select id="filterPerson"><option value="">Alle</option>${data().settings.people.map(item => `<option ${filters.person === item ? "selected" : ""}>${esc(item)}</option>`).join("")}</select>`)}
            ${field("Sortierung", `<select id="filterSort"><option value="newest">Neueste zuerst</option><option value="amount-desc" ${filters.sort === "amount-desc" ? "selected" : ""}>Betrag absteigend</option><option value="amount-asc" ${filters.sort === "amount-asc" ? "selected" : ""}>Betrag aufsteigend</option></select>`)}
          </div>
        </div>
      </div>
      <div class="card transaction-list">${items.length ? items.map(item => transactionRow(item, true)).join("") : '<div class="empty">Keine Treffer</div>'}</div>
    `;
  }

  function transactionFormMarkup() {
    return `
      <form id="transactionForm" class="form entry-form">
        ${field("Datum", `<input name="date" type="date" value="${today()}" required>`)}
        <div class="form-grid-two">
          ${field("Typ", `<select name="type"><option value="expense">Ausgabe</option><option value="income">Einnahme</option></select>`)}
          ${field("Betrag", `<input name="amount" type="number" inputmode="decimal" step="0.01" placeholder="0,00" required>`)}
        </div>
        ${field("Beschreibung", `<input name="description" placeholder="z. B. REWE Markt" required>`)}
        ${field("Konto", `<select name="accountId">${data().accounts.map(item => `<option value="${item.id}">${esc(item.name)}</option>`).join("")}</select>`)}
        ${field("Kategorie", `<select name="categoryId"><option value="">Automatisch erkennen</option>${data().categories.map(item => `<option value="${item.id}">${esc(item.name)}</option>`).join("")}</select>`)}
        ${field("Person", `<select name="person">${data().settings.people.map(item => `<option>${esc(item)}</option>`).join("")}</select>`)}
        <div class="entry-actions"><button class="btn primary">Buchung speichern</button></div>
      </form>
    `;
  }

  function addTransaction() {
    return `
      <div class="entry-screen">
        <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Neue Buchung</h2>
      </div>
      <div class="section-title page-title-spacer"></div>
        <div class="card page-card entry-card">${transactionFormMarkup()}</div>
      </div>
    `;
  }

  function addTransactionSheet() {
    return `
      <div class="sheet-heading">
        <span class="sheet-icon">${icons.plus}</span>
        <div><h2>Neue Buchung</h2><p>Ausgabe oder Einnahme erfassen</p></div>
      </div>
      <div class="sheet-form-card">${transactionFormMarkup()}</div>
    `;
  }

  function pending() {
    const items = sortNewest(data().transactions.filter(item => item.status === "pending"));
    return `
      <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Zu prüfen</h2>
      </div>
      <div class="section-title page-title-spacer"><span class="count-badge">${items.length}</span></div>
      <div class="card page-list">
        ${items.length ? items.map(item => `
          <div class="page-row">
            <div><strong>${esc(item.description)}</strong><div class="meta">${euro(item.amount)} · ${esc(item.person)}</div></div>
            <button class="btn ghost" data-resolve="${item.id}">Zuordnen</button>
          </div>
        `).join("") : '<div class="empty">Alles erledigt</div>'}
      </div>
    `;
  }

  function budgets() {
    const key = monthKey(today());
    const transactions = data().transactions.filter(item =>
      monthKey(item.date) === key && item.type === "expense"
    );

    const items = data().categories
      .filter(item => item.budget > 0)
      .map(item => {
        const used = transactions
          .filter(transaction => transaction.categoryId === item.id)
          .reduce((sum, transaction) => sum + Number(transaction.amount), 0);
        const percent = Math.max(0, item.budget ? used / item.budget * 100 : 0);
        return { ...item, used, percent };
      })
      .sort((a, b) => b.percent - a.percent);

    const rows = items.map(item => `
      <button class="grouped-row budget-row" data-budget="${item.id}">
        <span class="grouped-icon budget-symbol">${categoryIcon(item.name)}</span>
        <span class="grouped-main">
          <span class="grouped-title">${esc(item.name)}</span>
          <span class="grouped-meta">${euro(item.used)} von ${euro(item.budget)}</span>
          <span class="slim-progress" aria-hidden="true">
            <span class="slim-progress-fill" style="--row-progress:${Math.min(100, item.percent)}%"></span>
          </span>
        </span>
        <span class="grouped-values">
          <strong>${euro(Math.max(0, item.budget - item.used))}</strong>
        </span>
        <span class="row-chevron">${icons.chevron}</span>
      </button>
    `).join("");

    return `
      ${sectionHeader({ title: "Budgets", context: key })}
      ${items.length ? groupedCard(rows, "budget-group") : '<div class="card empty">Keine Budgets eingerichtet</div>'}
    `;
  }

  function loans() {
    const rows = [...data().loans]
      .sort((a,b) => Number(b.remaining) - Number(a.remaining))
      .map(loan => {
        const { paid, percent } = loanProgress(loan);
        return `
          <button class="grouped-row loan-detail-row" data-loan="${loan.id}">
            <span class="grouped-icon loan-symbol">${loanIcon(loan.type)}</span>
            <span class="grouped-main">
              <span class="grouped-title">${esc(loan.name)}</span>
              <span class="grouped-meta">${euro(paid)} abbezahlt · ${Math.round(percent)} %</span>
            </span>
            <span class="grouped-values"><strong>${euro(loan.remaining)}</strong></span>
            <span class="row-chevron">${icons.chevron}</span>
          </button>
        `;
      }).join("");

    return `
      <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Kredite</h2>
      </div>
      <div class="card grouped-card loan-detail-group">${rows}</div>
    `;
  }

  function more() {
    const install = getPWAState?.() ?? { standalone: false };
    const rows = [
      ["dashboard-settings", "Dashboard anpassen", icons.arrange],
      ["pending", "Später zuordnen", icons.pending],
      ["loans", "Kredite", icons.credit],
      ["manage", "Konten, Kategorien & Regeln", icons.settings],
      ["settings", "Einstellungen & Backup", icons.backup]
    ].map(([target, label, icon]) => `
      <button class="settings-row" data-nav="${target}">
        <span class="settings-icon">${icon}</span>
        <span class="settings-label">${label}</span>
        <span class="row-chevron">${icons.chevron}</span>
      </button>
    `).join("");

    return `
      <div class="section-title"><h2 class="page-heading">Mehr</h2></div>
      ${!install.standalone ? `
        <button class="card install-card" data-install-app>
          <span class="install-card-icon"><img src="./assets/icons/icon-96.png" alt=""></span>
          <span class="install-card-copy"><strong>FinanceOS installieren</strong><small>Wie eine echte App auf dem Startbildschirm</small></span>
          <span class="row-chevron">${icons.chevron}</span>
        </button>
      ` : ""}
      <div class="card grouped-card settings-group">${rows}</div>
    `;
  }

  function manage() {
    return `
      <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Konten</h2>
      </div>
      <div class="section-title page-title-spacer"><button class="btn primary" id="addAccount">＋</button></div>
      <div class="card page-list">${data().accounts.map(item => `<div class="page-row"><div><strong>${esc(item.name)}</strong><div class="meta">${euro(item.start)} Startsaldo</div></div><button class="btn ghost" data-account="${item.id}">Bearbeiten</button></div>`).join("")}</div>
      <div class="section-title"><h2 class="section-heading">Kategorien</h2><button class="btn primary" id="addCategory">＋</button></div>
      <div class="card page-list">${data().categories.map(item => `<div class="page-row"><div><strong>${esc(item.name)}</strong><div class="meta">Budget ${euro(item.budget)}</div></div><button class="btn ghost" data-category="${item.id}">Bearbeiten</button></div>`).join("")}</div>
      <div class="section-title"><h2 class="section-heading">Händlerregeln</h2><button class="btn primary" id="addRule">＋</button></div>
      <div class="card page-list">${data().rules.map(item => `<div class="page-row"><div><strong>${esc(item.needle)}</strong><div class="meta">→ ${esc(category(item.categoryId)?.name ?? "—")}</div></div><button class="btn ghost" data-rule="${item.id}">Bearbeiten</button></div>`).join("")}</div>
    `;
  }

  function dashboardSettings() {
    const config = data().settings.dashboard;
    const labels = {
      pending: "Zu prüfen",
      loans: "Kredite",
      transactions: "Letzte Buchungen"
    };
    const keys = Object.keys(labels);

    return `
      <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Dashboard anpassen</h2>
      </div>
      <div class="section-title page-title-spacer"></div>
      <div class="card page-card form">
        <div class="notice">
          Gesamtkontostand sowie Einnahmen und Ausgaben bleiben immer oben.
          Die Module darunter können ausgeblendet und neu geordnet werden.
        </div>
        ${keys.map(key => `
          <div class="dashboard-config-row">
            <div>
              <strong>${labels[key]}</strong>
              ${["loans","transactions"].includes(key) ? '<div class="meta">Anzahl sichtbarer Einträge</div>' : ""}
            </div>
            <div class="config-controls">
              <input class="toggle" type="checkbox" data-enable="${key}" ${config[key].enabled !== false ? "checked" : ""}>
              ${["loans","transactions"].includes(key)
                ? `<input type="number" min="0" max="${key === "loans" ? 3 : 20}" value="${config[key].count ?? 0}" data-count="${key}">`
                : ""}
              <select data-order="${key}">
                ${[1,2,3].map(number => `<option value="${number}" ${Number(config[key].order) === number ? "selected" : ""}>${number}</option>`).join("")}
              </select>
            </div>
          </div>
        `).join("")}
        <button class="btn primary" id="saveDashboard">Speichern</button>
      </div>
    `;
  }

  function settings() {
    return `
      <div class="section-title"><h2 class="page-heading">Einstellungen & Daten</h2></div>
      <div class="card page-card form">
        <button class="btn primary" id="backupButton">Backup erstellen</button>
        <label class="btn ghost" style="text-align:center">Backup wiederherstellen<input id="restoreInput" type="file" accept="application/json" hidden></label>
        <button class="btn danger ghost" id="resetButton">Beispieldaten zurücksetzen</button>
        <div class="notice">FinanceOS ${APP_VERSION} · Backups auf dem iPhone über „In Dateien sichern“ in iCloud Drive ablegen.</div>
      </div>
    `;
  }


  function accounts() {
    return `
      <div class="section-title"><h2 class="page-heading">Konten</h2></div>
      <div class="card page-list">
        ${data().accounts.map(item => `
          <div class="page-row">
            <div><strong>${esc(item.name)}</strong><div class="meta">${esc(item.type)}</div></div>
            <strong>${euro(accountBalance(data(), item.id))}</strong>
          </div>
        `).join("")}
      </div>
    `;
  }

  function income() {
    const items = sortNewest(data().transactions.filter(item => item.type === "income"));
    return `
      <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Einnahmen</h2>
      </div>
      <div class="section-title page-title-spacer"></div>
      <div class="card transaction-list">
        ${items.length ? items.map(item => transactionRow(item, true)).join("") : '<div class="empty">Keine Einnahmen</div>'}
      </div>
    `;
  }

  function expenses() {
    const items = sortNewest(data().transactions.filter(item => item.type === "expense"));
    return `
      <div class="page-header">
        <button class="back-button" data-back aria-label="Zurück">${icons.back}</button>
        <h2 class="page-heading">Ausgaben</h2>
      </div>
      <div class="section-title page-title-spacer"></div>
      <div class="card transaction-list">
        ${items.length ? items.map(item => transactionRow(item, true)).join("") : '<div class="empty">Keine Ausgaben</div>'}
      </div>
    `;
  }

  return {
    dashboard, transactions, addTransaction, pending, budgets,
    loans, more, manage, dashboardSettings, settings,
    accounts, income, expenses, addTransactionSheet, transactionRow
  };
}
